# Development network

This network only contains one organization with one peer and uses GoLevelDB as state storage. This is supposed to be a lightweight network for quickly testing new features even on weaker machine configurations.