# 2-Org-3-Peer

This folder contains configration data for Fabric 1.1.0, with the following structure:
 * 2 organisations
 * Each organisation with 3 peers